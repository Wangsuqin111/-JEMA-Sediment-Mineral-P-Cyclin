# JEMA审稿人7：处理后数据和分析代码（最终整合候选包）

只公开审稿人要求的处理后床面剪切力、XRD矿物、71份泥样微生物/磷基因矩阵、CLR-PCA、PERMANOVA、dbRDA变异分解与61样本路径模型。**尚未上传GitHub。**

运行Python：`python -m pip install -r requirements.txt`，再运行 `python run_all.py` 和 `python verify_replay.py`。

运行正式R复核：安装 `zCompositions`、`openxlsx` 和 `vegan`，双击 `RUN_CZM_AND_VARPART_R.bat`，或在RStudio中于项目根目录依次执行 `source("code/01_recovered_CZM_CLR_PCA.R",encoding="UTF-8")`、`source("code/05_optional_dbrda_variation_partition.R",encoding="UTF-8")`。

本次已收到研究者R运行产生的正式dbRDA结果CSV（保存在 `results/varpart_optional_dbrda_CZM/pure_fractions_dbrda.csv`）：70样本、矿物5轴调整R²=0.02512446 P=0.0193、水体5轴0.03900159 P=0.0057、沉积物4轴0.06184098 P=0.0011，全部9,999次置换。现有执行环境无R，不能宣称由打包机再次独立重跑R；已核对CSV与脚本的预期结构一致。

历史零值替代方法：`zCompositions::cmultRepl(method="CZM")`。历史CLR-PC1=45.0365%、ARI=0.570432及9个样本改组，均由用户的RStudio执行输出确认。连续群落PERMANOVA R²=0.033925 P=0.0128；磷功能R²=0.038542 P=0.0195。61样本路径模型采用独立SLR矿物节点。

**注意论文同步：** 10月13日重建法（PC1 52.8%、Hellinger-RDA三组调整R²=0.0270/0.0618/0.0773）不是此次最终分析，不得用于最终正文、补充表和图注。详细替换说明参见 `PUBLICATION_UPDATES_REQUIRED.md`。
