@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 run_all.py & goto end)
where python >nul 2>nul
if not errorlevel 1 (python run_all.py & goto end)
echo Python not found. Install Python 3.12 and dependencies in requirements.txt
:end
pause
