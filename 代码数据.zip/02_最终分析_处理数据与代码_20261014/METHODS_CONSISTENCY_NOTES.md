# Verified cross-method boundaries and caveats

1. Original CZM/CLR (10-component, 75 XRD profiles) PC1 explains 45.0365% (not 52.8%). Researcher successfully executed original R method and recovered ARI 0.570432 and 9/75 Ward.D2 assignment changes. Archived output is original.
2. Python replays of continuous Bray PERMANOVA from archived PC1: genus R² 0.033925/P 0.0128; P-family R² 0.038542/P 0.0195. Monte Carlo P varies with seed/engine.
3. FORMAL variation partition: **partial Bray–Curtis dbRDA with Lingoes correction**, 70 matched sediments, 5 mineral/5 water/4 sediment PCs, 9999 permutations. The researcher-supplied R results: mineral .02512446/P .0193, water .03900159/P .0057, sediment .06184098/P .0011. These are *not* Hellinger RDA fractions.
4. Python tests confirm source file structures, output values, original path-model replay from archived composite scores. Independent R re-execution occurred on researcher's PC, not in this Python-only build environment.
5. Remaining manuscript consistency checks: discard the October-13 52.8% and nonsignificant continuous assertions; update Methods (dbRDA), Results and supplementary Table S11; harmonize Figure 2 alpha/FDR and PERMDISP values if presenting code-exact statistics; do not claim all manuscript figures fully reproduced without review.
6. Public repository not yet created. No unnecessary original read, full hydraulic model, raw diffraction, or other unrelated analyses in this archive.
