# JEMA Reviewer 7 — targeted processed data and analysis code (final integrated candidate)

This deposit is deliberately limited to the requested **processed hydrodynamic/XRD data, sediment metagenomic genus and phosphorus-gene abundance matrices, compositional analysis, PERMANOVA, variation partitioning, and piecewise path modelling**. It does **not** contain raw FASTQ, complete MIKE 11 model engineering files, raw XRD diffraction patterns or unrelated analyses. No public upload to GitHub has yet been made.

## Execution

- Python 3.12+: `python -m pip install -r requirements.txt`, then `python run_all.py` and `python verify_replay.py`.
- Windows: `RUN_WINDOWS.bat` runs Python. With **R installed and packages zCompositions, openxlsx and vegan**, `RUN_CZM_AND_VARPART_R.bat` independently regenerates the historic CZM/CLR-PCA and the **formal Bray–Curtis dbRDA with Lingoes correction**.
- Manual RStudio alternative (from repository root):

```r
source("code/01_recovered_CZM_CLR_PCA.R", encoding="UTF-8")
source("code/05_optional_dbrda_variation_partition.R", encoding="UTF-8")
```

Both R scripts require the included `data/` folder and will write into `results/`. Python does not run either R script automatically. The Oct 14 dbRDA output was generated in R **by the researcher** and is included at `results/varpart_optional_dbrda_CZM/pure_fractions_dbrda.csv`; this packaging environment independently checks its structural consistency but lacks R to re-execute it.

## Source-backed results

| Method | N | Reproducibility boundary | Main estimates |
|---|---:|---|---|
| Ten-component XRD CZM -> CLR -> unscaled PCA | 75 | Historical source R code plus archived genuine scores, loadings and variance; researcher independently reran and observed numerical PASS | PC1 45.0365%, PC2 19.9583% |
| Aitchison/Ward.D2 cluster sensitivity | 75 | Same researcher-run R output | ARI 0.570432; 9 reassigned |
| Continuous genus Bray–Curtis PERMANOVA against historic mineral PC1 | 71 | Python from saved authentic PC1 and genus matrix, 9999 permutations | R²=0.033925, P=0.0128 |
| Continuous PCycDB family Bray–Curtis PERMANOVA | 71 | Python from saved authentic PC1 and 160-family matrix, 9999 permutations | R²=0.038542, P=0.0195 |
| Three-block Bray–Curtis/Lingoes **partial dbRDA** | 70 | Source R analysis and researcher-run exact CSV | Mineral adj.R²=.02512446 P=.0193; Water .03900159 P=.0057; Sediment .06184098 P=.0011 |
| SLR-based piecewise path model | 61 | Python replay from genuine **archived composite scores**, 999 bootstrap iterations | 48/48 published Table S5 stats agree at rounding precision |

**R analysis details:** Environmental blocks use mineral CZM-CLR PCs (5 axes; 80.87% variance), water physicochemistry (5; 87.22%), sediment physicochemistry (4; 89.95%). Genus abundance is within-sample normalized; response uses Bray–Curtis dissimilarity and Lingoes correction. Each conditional block is tested controlling for the other two blocks, with 9999 permutations (seed 20261013). The CSV names are `M`, `W`, `S`.

## Scientific interpretation and existing manuscript divergence

- These formal **dbRDA** fractions must **not** be confused with the superseded **Hellinger-RDA** estimates (`0.0270 / 0.0618 / 0.0773`). The latter reconstruction is excluded from this deposit.
- The original CZM mineral PC1 (45.0%) is not the alternative Oct 13 minimum-positive-times-0.65 PC1 (52.8%). The latter is excluded; its non-significant continuous-gradient results should not appear in the final paper.
- Permutation P values from this fixed Python protocol (`0.0128`, `0.0195`) differ modestly from previous paper values (`0.0133`, `0.0160`). Choose the published numerical set consistently across manuscript, figures and Supplementary Table S2.
- Original Richness/mineral PC1 Spearman rho (`0.017`) does not match the exposed processed input (`0.08595`); likewise some class-level alpha FDR values and PERMDISP differ. **Final-text check remains necessary** outside the limited R/dbRDA validation. Do not claim all figure stats match automatically.
- The historical path model uses the **summed logratio (SLR)** mineral node; it is separate from the ten-component CZM CLR-PC1.
- The 61-sample path model reproduces results starting from **genuine archived composite scores**, not from original sequencing reads or raw model files.

See `PUBLICATION_UPDATES_REQUIRED.md` for numerical replacements and recommended manuscript wording. The R output is the user's supplied file, retained exactly (no numerical adjustment).
