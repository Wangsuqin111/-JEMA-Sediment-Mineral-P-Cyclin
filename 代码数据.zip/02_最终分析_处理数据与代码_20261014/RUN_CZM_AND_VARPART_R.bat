@echo off
setlocal
cd /d "%~dp0"
where Rscript >nul 2>nul
if errorlevel 1 (echo Rscript not found. Install R first. & pause & exit /b 1)
Rscript code/01_recovered_CZM_CLR_PCA.R
if errorlevel 1 (echo CZM R audit failed. & pause & exit /b 1)
Rscript code/05_optional_dbrda_variation_partition.R
if errorlevel 1 (echo dbRDA failed. & pause & exit /b 1)
echo CZM and formal dbRDA completed.
pause
