from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parent
for name in ["00_core_replay_XRD_genes_path.py", "02_historical_continuous_PERMANOVA_original.py"]:
    print(f"\n=== RUNNING {name} ===",flush=True)
    subprocess.run([sys.executable, str(ROOT/"code"/name)],cwd=ROOT,check=True)
print("\nPython replay finished. To independently recalculate official dbRDA, run RUN_CZM_AND_VARPART_R.bat on Windows with R installed, or run both R scripts in order.",flush=True)
