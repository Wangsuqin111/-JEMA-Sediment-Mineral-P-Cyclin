from pathlib import Path
import csv,hashlib,sys
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parent
R=ROOT/'results'; X=ROOT/'data'
checks=[]
def add(name,ok,info):
 checks.append({'check':name,'pass':bool(ok),'details':str(info)})
 if not ok:print('FAIL',name,info)
x=pd.read_csv(X/'mineral/XRD_mineral_assemblages_75.csv');old=pd.read_csv(X/'mineral/historical_CZM_CLR_PCA_sample_scores_75.csv',encoding='utf-8-sig')
m=x.merge(old[['SampleID','PC1']],on='SampleID',validate='one_to_one')
add('75 XRD composition samples',len(x)==75 and x.SampleID.is_unique,len(x))
add('historical original PC1 versus processed XRD table',np.allclose(m.PC1_x,m.PC1_y,atol=1e-12),float(abs(m.PC1_x-m.PC1_y).max()))
v=pd.read_csv(X/'mineral/historical_CZM_CLR_PCA_variance.csv',encoding='utf-8-sig');add('historical CZM PC1 variance 45.0365%',abs(v.Variance_explained.iloc[0]-.4503654386688366)<1e-12,v.Variance_explained.iloc[0])
meta=pd.read_csv(X/'microbiome/sediment_metadata_71.csv');genes=pd.read_csv(X/'phosphorus/PCycDB_family_TPM_160x71.csv.gz')
add('71 sediment-only metagenomes',len(meta)==71 and all(meta.SampleID.str.endswith('-ni')),len(meta))
add('71 samples x 160 gene families',genes.shape==(71,161) and set(genes.SampleID)==set(meta.SampleID),genes.shape)
p=pd.read_csv(R/'historical_continuous/HISTORICAL_CONTINUOUS_PERMANOVA.csv').set_index('analysis')
add('continuous Genus R2',abs(p.loc['Genus_Historical_PC1','R2']-.03392469587149227)<1e-11,p.loc['Genus_Historical_PC1','R2'])
add('continuous P-function R2',abs(p.loc['P_gene_Historical_PC1','R2']-.03854161744853083)<1e-11,p.loc['P_gene_Historical_PC1','R2'])
add('significant two historical-PC1 continuous PERMANOVAs',all(p.loc[['Genus_Historical_PC1','P_gene_Historical_PC1'],'P']<0.05),p.loc[['Genus_Historical_PC1','P_gene_Historical_PC1'],'P'].to_dict())
pa=pd.read_csv(R/'core/whole_system_61_paths_bootstrap999.csv')
add('whole-system path counts and 999 bootstrap',len(pa)==12 and (pa.N==61).all() and (pa.B==999).all(),pa.shape)
# Compare freshly generated path values with archived reported values, not saved pass flags.
oldverify=pd.read_csv(ROOT/'archive_provenance'/'TableS5_published_precision_targets.csv')
replay=pa.set_index('Path')
full_check=[]
for row in oldverify.itertuples(index=False):
    path,metric=row.metric.rsplit(' / ',1)
    obs=float(replay.loc[path,metric])
    ok=abs(obs-float(row.manuscript_target))<=float(row.tolerance)
    full_check.append({'Path':path,'Statistic':metric,'Recalculated':obs,'Paper_3dec':row.manuscript_target,'Tolerance':row.tolerance,'Pass':ok})
pd.DataFrame(full_check).to_csv(R/'TableS5_48_statistic_verification_FRESH.csv',index=False)
add('48 freshly compared checks against Table S5',len(full_check)==48 and all(c['Pass'] for c in full_check),f'{sum(c["Pass"] for c in full_check)}/48')
# User ran the original-CZM + formal Bray-Lingoes dbRDA script in R; its exact
# result CSV is archived here. Compare archived stats against the expected
# three blocks, 70 sample matches, and 9999 permutations. This is NOT a claim
# that this Python checker independently ran R or recalculated permutation P.
vp=pd.read_csv(R/'varpart_optional_dbrda_CZM/pure_fractions_dbrda.csv').set_index('Block')
add('official R/dbRDA output schema', set(['M','W','S'])==set(vp.index) and len(vp)==3, list(vp.index))
add('official R/dbRDA sample counts and permutation counts', (vp.N==70).all() and (vp.Permutations==9999).all(),vp[['N','Permutations']].to_dict('index'))
expected={'M':(5,.0251244614704236,.0193),'W':(5,.0390015935486485,.0057),'S':(4,.0618409786325527,.0011)}
for block,(axes,r2,p) in expected.items():
    rec=vp.loc[block]
    add(f'formal R dbRDA {block} archived-statistics audit',int(rec.Axes)==axes and abs(rec.Partial_dbrda_adjusted_R2-r2)<1e-12 and abs(rec.P-p)<1e-12, f'R2={rec.Partial_dbrda_adjusted_R2}, P={rec.P}')
summary=pd.DataFrame(checks);summary.to_csv(R/'verification_summary.csv',index=False)
print(summary.to_string(index=False));
if not summary['pass'].all():sys.exit(1)
print('Processed-data Python replay and supplied formal R/dbRDA output audit PASS. The R models were run by the researcher, not independently executed in this Python environment.')
