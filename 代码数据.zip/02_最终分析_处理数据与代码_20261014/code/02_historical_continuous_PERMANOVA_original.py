from pathlib import Path
import numpy as np,pandas as pd
from scipy.spatial.distance import pdist,squareform
from scipy import stats
root=Path(__file__).resolve().parent.parent/'data'
(root.parent/'results'/'historical_continuous').mkdir(exist_ok=True,parents=True)
xrd=pd.read_csv(root/'mineral'/'XRD_mineral_assemblages_75.csv')
meta=pd.read_csv(root/'microbiome'/'sediment_metadata_71.csv')
g=pd.read_csv(root/'microbiome'/'genus_abundance_71.tsv.gz',sep='\t')
f=pd.read_csv(root/'phosphorus'/'PCycDB_family_TPM_160x71.csv.gz')
a=pd.read_csv(root/'microbiome'/'genus_alpha_diversity_71.csv')
old=pd.read_csv(root/'mineral'/'historical_CZM_CLR_PCA_sample_scores_75.csv',encoding='utf-8-sig')
lookup=meta.merge(old[['SampleID','PC1']],left_on='Mineral_SampleID',right_on='SampleID',validate='one_to_one')
assert lookup.SampleID_x.tolist()==meta.SampleID.tolist()
assert len(lookup)==71
matched=xrd.merge(old,on='SampleID',validate='one_to_one');assert np.allclose(matched.PC1_x,matched.PC1_y,atol=1e-12)
G=g.set_index(g.columns[0])[meta.SampleID.tolist()].to_numpy(dtype=float).T;G=G/G.sum(axis=1,keepdims=True)
F=f.set_index('SampleID').loc[meta.SampleID].to_numpy(dtype=float);F=F/F.sum(axis=1,keepdims=True)
def Bmat(arr):
 d=squareform(pdist(arr,'braycurtis'));n=len(d); j=np.eye(n)-np.ones((n,n))/n;return -.5*j@(d*d)@j
def perma(B,vec,seed=20261013,N=9999):
 x=np.asarray(vec,float);x=x-x.mean();t=np.trace(B);r=(x@B@x)/(x@x)/t
 rng=np.random.default_rng(seed);n=0
 for i in range(N):
  v=x[rng.permutation(len(x))];n+=((v@B@v)/(v@v)/t>=r-1e-12)
 return {'R2':float(r),'P':(n+1)/(N+1),'N':len(x),'seed':seed,'permutations':N}
rows=[]
for label,B in [('Genus',Bmat(G)),('P_gene',Bmat(F))]:
 for typ,vals in [('Class',meta.Group_1_clay_enriched_2_depleted),('Historical_PC1',lookup.PC1)]:
  rows.append(dict(analysis=label+'_'+typ,**perma(B,vals)))
res=pd.DataFrame(rows);res.to_csv(root.parent/'results'/'historical_continuous'/'HISTORICAL_CONTINUOUS_PERMANOVA.csv',index=False)
print(res.to_string(index=False))
alpha= a.merge(lookup[['SampleID_x','PC1']],left_on='SampleID',right_on='SampleID_x',validate='one_to_one')
arr=[]
for m in ['Richness','Shannon','Simpson']:
 rho,p=stats.spearmanr(alpha.PC1,alpha[m]);arr.append({'metric':m,'rho':rho,'p':p})
ares=pd.DataFrame(arr);ares['BH_FDR']=stats.false_discovery_control(ares.p.to_numpy(),method='bh');ares.to_csv(root.parent/'results'/'historical_continuous'/'HISTORICAL_ALPHA_PC1.csv',index=False);print(ares.to_string(index=False))
