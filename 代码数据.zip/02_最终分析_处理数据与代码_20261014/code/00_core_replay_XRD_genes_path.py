"""Lightweight reproducibility replay from archived processed input tables.
No plots. All statistics recomputed from the archived data, never read from paper tables.
The additional code/ scripts cover complete panels, variation partition and figures.
"""
from pathlib import Path
import numpy as np,pandas as pd
from scipy import stats
from scipy.spatial.distance import pdist,squareform
ROOT=Path(__file__).resolve().parent.parent;OUT=ROOT/'results'/'core';OUT.mkdir(parents=True,exist_ok=True)
# XRD and hydrodynamic summaries from 75 + 70 records
xrd=pd.read_csv(ROOT/'data/mineral/XRD_mineral_assemblages_75.csv');bss=pd.read_csv(ROOT/'data/mineral/modelled_BSS_75site_crosswalk_70_valid.csv')
clay=xrd[['伊利石','高岭石','斜绿泥石','绿泥石']].sum(axis=1)
rock=xrd[['石英','钠长石','钾长石']].sum(axis=1)
assert len(xrd)==75 and (clay>0).all() and (rock>0).all()
assert np.max(np.abs(np.log(clay/rock)-xrd.SLR))<1e-10
pd.DataFrame({'SampleID':xrd.SampleID,'Group':xrd.Group,'recalculated_SLR':np.log(clay/rock),'archived_CLR_PC1':xrd.PC1}).to_csv(OUT/'mineral_SLR_archived_PC1_75.csv',index=False)
d=xrd[['SampleID','Group','石英','白云母']].assign(Clay_related_sum=clay).merge(bss,on='SampleID',validate='one_to_one')
print('BSS columns:',list(bss.columns),flush=True)
if 'BSS_authoritative' not in d:raise ValueError('Missing BSS_authoritative')
d=d.dropna(subset=['BSS_authoritative'])
assert len(d)==70
corr=[]
for name in ['石英','白云母','Clay_related_sum']:
 rho,p=stats.spearmanr(d.BSS_authoritative,d[name]);corr.append({'Mineral':name,'n':70,'Spearman_rho':rho,'P':p})
pd.DataFrame(corr).to_csv(OUT/'BSS_XRD_correlations_70.csv',index=False)
# 160 gene families, same declared correction family as manuscript
m=pd.read_csv(ROOT/'data/microbiome/sediment_metadata_71.csv');p=pd.read_csv(ROOT/'data/phosphorus/PCycDB_family_TPM_160x71.csv.gz')
family=list(p.columns[1:]);assert len(m)==len(p)==71 and len(family)==160
mp=m[['SampleID','Group_1_clay_enriched_2_depleted','CLR_PCA_PC1']].merge(p,on='SampleID',validate='one_to_one')
y=mp['Group_1_clay_enriched_2_depleted'].to_numpy();rows=[]
for g in family:
 a=mp.loc[y==1,g].to_numpy(float);b=mp.loc[y==2,g].to_numpy(float)
 if np.all(a==a[0]) and np.all(b==b[0]) and a[0]==b[0]:z=1.0
 else:z=float(stats.mannwhitneyu(a,b,alternative='two-sided',method='asymptotic',use_continuity=True).pvalue)
 if not np.isfinite(z):raise ValueError(f'Non-finite P value for {g}')
 rows.append({'gene_family':g,'P':z})
a=pd.DataFrame(rows);a['BH_FDR_160']=stats.false_discovery_control(a.P.to_numpy(),method='bh');a.to_csv(OUT/'PCycDB_160_Wilcoxon_BH.csv',index=False)
# Bray functional PERMANOVA: sample-normalized 160-family TPM, 9999 permutations
X=mp[family].to_numpy(float);X/=X.sum(axis=1)[:,None]
D=squareform(pdist(X,metric='braycurtis'));n=len(D);H=np.eye(n)-np.ones((n,n))/n;B=-.5*H@(D**2)@H;T=np.trace(B)
frows=[]
for label,x in [('operational_class',y),('archived_mineral_PC1',mp.CLR_PCA_PC1.to_numpy())]:
 x=np.asarray(x,float);x=x-x.mean();r2=float(x@B@x/(x@x)/T)
 rng=np.random.default_rng(20261013);hits=0
 for k in range(9999):
  xp=x[rng.permutation(n)];hits+=int(float(xp@B@xp/(xp@xp)/T)>=r2-1e-12)
 frows.append({'predictor':label,'n':n,'R2':r2,'permutation_P':(hits+1)/10000})
pd.DataFrame(frows).to_csv(OUT/'PCycDB_160_PERMANOVA_71.csv',index=False)
# Genus-level community PERMANOVA and diversity: 71 mud samples only
meta=m[['SampleID','Group_1_clay_enriched_2_depleted']].copy()
g=pd.read_csv(ROOT/'data/microbiome/genus_abundance_71.tsv.gz',sep='\t',compression='gzip')
assert g.shape[1]==72
G=g.set_index(g.columns[0]).T
G.index.name='SampleID';G=G.astype(float)
ids=meta.SampleID.tolist();assert set(ids)==set(G.index)
G=G.loc[ids].to_numpy();G/=G.sum(axis=1)[:,None]
GD=squareform(pdist(G,metric='braycurtis'));GH=np.eye(71)-np.ones((71,71))/71;GB=-.5*GH@(GD**2)@GH;GT=np.trace(GB)
gx=y-y.mean();gr2=float(gx@GB@gx/(gx@gx)/GT)
grng=np.random.default_rng(20261013);hits=0
for k in range(9999):
 xp=gx[grng.permutation(71)];hits+=int(float(xp@GB@xp/(xp@xp)/GT)>=gr2-1e-12)
pd.DataFrame([{'metric':'Genus Bray PERMANOVA operational class','N':71,'R2':gr2,'permutation_P':(hits+1)/10000,'B':9999}]).to_csv(OUT/'genus_71_PERMANOVA.csv',index=False)
alpha=pd.read_csv(ROOT/'data/microbiome/genus_alpha_diversity_71.csv').merge(meta,on='SampleID')
assert len(alpha)==71
arows=[]
for metric in ['Richness','Shannon','Simpson']:
 v1=alpha.loc[alpha.Group_1_clay_enriched_2_depleted==1,metric].to_numpy(float)
 v2=alpha.loc[alpha.Group_1_clay_enriched_2_depleted==2,metric].to_numpy(float)
 ps=float(stats.mannwhitneyu(v1,v2,alternative='two-sided',method='asymptotic',use_continuity=True).pvalue)
 arows.append({'metric':metric,'P':ps})
aa=pd.DataFrame(arows);aa['BH_FDR_3']=stats.false_discovery_control(aa.P.to_numpy(),method='bh')
aa.to_csv(OUT/'genus_71_alpha_Wilcoxon_BH.csv',index=False)
# 61-sample piecewise path model, exact reported bootstrap design seed=1001 n=999
s=pd.read_csv(ROOT/'data/path_model/path_composite_scores_61.csv');assert len(s)==61
order=[('Mineral',['Hydro']),('Water',['Hydro','Mineral']),('Sediment',['Hydro','Mineral']),('Microbial',['Mineral','Water','Sediment']),('PFunction',['Hydro','Water','Sediment','Microbial'])]
vars=['Hydro','Mineral','Water','Sediment','Microbial','PFunction'];arr=s[vars].to_numpy(float)
def fit(x):
 z=(x-x.mean(axis=0))/x.std(axis=0,ddof=1)
 out={};r2={}
 for resp,predictors in order:
  yi=vars.index(resp);xi=[vars.index(v) for v in predictors];Y=z[:,yi];A=np.column_stack([np.ones(len(z)),z[:,xi]])
  bet=np.linalg.lstsq(A,Y,rcond=None)[0];yhat=A@bet
  r2[resp]=1-float(((Y-yhat)**2).sum()/((Y-Y.mean())**2).sum())
  for k,pred in enumerate(predictors):out[f'{pred} -> {resp}']=float(bet[k+1])
 return out,r2
b,r=fit(arr);rng=np.random.default_rng(1001);boots={k:[] for k in b}
for _ in range(999):
 xb=arr[rng.integers(0,len(arr),size=len(arr))]
 bb,_=fit(xb)
 for k,v in bb.items():boots[k].append(v)
report=[]
for k,val in b.items():
 v=np.array(boots[k]);lo,hi=np.quantile(v,[.025,.975]);bp=min(1.,2*min(((v<=0).sum()+1)/1000,((v>=0).sum()+1)/1000))
 report.append({'Path':k,'Beta':val,'CI_low':lo,'CI_high':hi,'Boot_P':bp,'N':61,'B':999})
pd.DataFrame(report).to_csv(OUT/'whole_system_61_paths_bootstrap999.csv',index=False)
pd.DataFrame([{'Node':k,'R2':v} for k,v in r.items()]).to_csv(OUT/'whole_system_61_R2.csv',index=False)
print('CORE REPLAY SUCCESS: 75 XRD; 70 BSS; 71 genus/P gene samples; 160 gene-family tests; 9999 PERMANOVA permutations; 61-sample SEM with 999 bootstraps.',flush=True)
