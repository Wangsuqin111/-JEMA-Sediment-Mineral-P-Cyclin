############################################################
## Stage 1: 10-component XRD compositional PCA diagnostic
## Purpose:
##   1) use all 75 XRD samples to define a single global CLR-PCA basis;
##   2) diagnose whether PC1 is an appropriate mineral-composition construct
##      before it is introduced into downstream piecewise SEM;
##   3) never select axes based on downstream significance.
############################################################

options(stringsAsFactors = FALSE)

# Same analysis workflow as the recovered 7-Oct-2026 script.
# New I/O only: read the deposited 75-site processed mineral CSV.
INPUT_CSV <- file.path("data", "mineral", "XRD_mineral_assemblages_75.csv")
OUT_DIR <- file.path("results", "CZM_CLR_R")
if (!dir.exists(OUT_DIR)) dir.create(OUT_DIR, recursive = TRUE)

required_packages <- c("zCompositions", "openxlsx")
for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop(paste0("Missing R package: ",pkg, ". Run install.packages('",pkg,"') first."))
  }
}

library(zCompositions)
library(openxlsx)

set.seed(20261007)

## ---------------------------------------------------------
## 1. Read data
## ---------------------------------------------------------
dat <- read.csv(INPUT_CSV, check.names = FALSE, fileEncoding = "UTF-8-BOM")
dat$station <- dat$SampleID
saved_scores <- read.csv(file.path("data", "mineral", "historical_CZM_CLR_PCA_sample_scores_75.csv"), check.names = FALSE, fileEncoding = "UTF-8-BOM")
dat$`剪切力` <- saved_scores$Bed_shear_stress[match(dat$SampleID, saved_scores$SampleID)]
if (anyDuplicated(dat$SampleID) || nrow(dat) != 75) stop("Expected 75 unique XRD samples")

required_cols <- c(
  "station", "Group",
  "石英", "伊利石", "钠长石", "白云母", "斜绿泥石",
  "高岭石", "钾长石", "方解石", "白云石", "绿泥石",
  "剪切力"
)
missing_cols <- setdiff(required_cols, names(dat))
if (length(missing_cols) > 0) {
  stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
}

mineral_cols <- c(
  "石英", "伊利石", "钠长石", "白云母", "斜绿泥石",
  "高岭石", "钾长石", "方解石", "白云石", "绿泥石"
)

X <- as.matrix(dat[, mineral_cols])
storage.mode(X) <- "numeric"
rownames(X) <- dat$station

if (any(!is.finite(X))) stop("Non-finite XRD values detected.")
if (any(X < 0)) stop("Negative XRD values detected.")
if (any(rowSums(X) <= 0)) stop("At least one sample has non-positive mineral sum.")

## ---------------------------------------------------------
## 2. Closure + CZM zero replacement + CLR
## ---------------------------------------------------------
X_prop <- X / rowSums(X)

if (any(X_prop == 0)) {
  X_czm <- zCompositions::cmultRepl(
    X_prop,
    label = 0,
    method = "CZM",
    output = "prop"
  )
} else {
  X_czm <- X_prop
}

X_clr <- t(apply(X_czm, 1, function(x) {
  lx <- log(x)
  lx - mean(lx)
}))
colnames(X_clr) <- mineral_cols
rownames(X_clr) <- dat$station

## ---------------------------------------------------------
## 3. Global PCA: fitted once on all XRD samples
## ---------------------------------------------------------
## Center variables across samples, but do NOT scale to unit variance.
pca_fit <- prcomp(X_clr, center = TRUE, scale. = FALSE)

scores <- pca_fit$x
loadings <- pca_fit$rotation
variance <- pca_fit$sdev^2 / sum(pca_fit$sdev^2)

## Sign is arbitrary. Orient each axis only for readability so that
## Spearman correlation with the operational clay-related sum is positive.
## This sign flip does not change variance, P values, R2 or model fit.
clay_sum <- rowSums(X[, c("伊利石", "斜绿泥石", "高岭石", "绿泥石"), drop = FALSE])
feldspar <- X[, "钠长石"] + X[, "钾长石"]
carbonate <- X[, "方解石"] + X[, "白云石"]

for (k in seq_len(ncol(scores))) {
  rho_k <- suppressWarnings(cor(scores[, k], clay_sum, method = "spearman"))
  if (is.finite(rho_k) && rho_k < 0) {
    scores[, k] <- -scores[, k]
    loadings[, k] <- -loadings[, k]
  }
}

## ---------------------------------------------------------
## 4. Diagnostics: PC interpretation must precede SEM use
## ---------------------------------------------------------
assoc_variables <- data.frame(
  `Operational clay-related sum` = clay_sum,
  Quartz = X[, "石英"],
  Feldspar = feldspar,
  Carbonate = carbonate,
  Calcite = X[, "方解石"],
  `Bed shear stress` = suppressWarnings(as.numeric(dat$剪切力)),
  check.names = FALSE
)

assoc_list <- list()
idx <- 1
for (k in 1:3) {
  for (v in names(assoc_variables)) {
    x <- scores[, k]
    y <- assoc_variables[[v]]
    keep <- is.finite(x) & is.finite(y)
    test <- suppressWarnings(cor.test(x[keep], y[keep], method = "spearman", exact = FALSE))
    assoc_list[[idx]] <- data.frame(
      PC = paste0("PC", k),
      Variable = v,
      N = sum(keep),
      Spearman_rho = unname(test$estimate),
      P_value = test$p.value
    )
    idx <- idx + 1
  }
}
association_table <- do.call(rbind, assoc_list)

## Group contrast is descriptive only; Group 1/2 are not used to fit PCA.
group_table <- do.call(rbind, lapply(1:3, function(k) {
  g1 <- scores[dat$Group == 1, k]
  g2 <- scores[dat$Group == 2, k]
  wt <- wilcox.test(g1, g2, exact = FALSE)
  ## Cliff's delta from pairwise comparisons.
  delta <- mean(outer(g1, g2, ">")) - mean(outer(g1, g2, "<"))
  data.frame(
    PC = paste0("PC", k),
    N_Group1 = length(g1),
    N_Group2 = length(g2),
    Mean_Group1 = mean(g1),
    Mean_Group2 = mean(g2),
    Wilcoxon_P = wt$p.value,
    Cliffs_delta = delta
  )
}))

## ---------------------------------------------------------
## 5. Export
## ---------------------------------------------------------
component_qc <- data.frame(
  Component = mineral_cols,
  Mean = colMeans(X),
  Median = apply(X, 2, median),
  Zero_count = colSums(X == 0),
  Zero_pct = colMeans(X == 0),
  Min = apply(X, 2, min),
  Max = apply(X, 2, max),
  row.names = NULL
)

variance_table <- data.frame(
  PC = paste0("PC", seq_along(variance)),
  Variance_explained = variance,
  Cumulative_variance = cumsum(variance)
)

loading_table <- data.frame(
  Component = mineral_cols,
  PC1 = loadings[, 1],
  PC2 = loadings[, 2],
  PC3 = loadings[, 3],
  row.names = NULL
)

score_table <- data.frame(
  SampleID = dat$station,
  Group = dat$Group,
  Clay_related_sum = clay_sum,
  Feldspar = feldspar,
  Carbonate = carbonate,
  Bed_shear_stress = suppressWarnings(as.numeric(dat$剪切力)),
  PC1 = scores[, 1],
  PC2 = scores[, 2],
  PC3 = scores[, 3],
  row.names = NULL
)

summary_table <- data.frame(
  Item = c(
    "N_XRD_samples",
    "N_Group1",
    "N_Group2",
    "PC1_variance",
    "PC2_variance",
    "PC1_PC2_cumulative",
    "Primary_decision_rule"
  ),
  Value = c(
    nrow(X),
    sum(dat$Group == 1, na.rm = TRUE),
    sum(dat$Group == 2, na.rm = TRUE),
    variance[1],
    variance[2],
    sum(variance[1:2]),
    paste(
      "Axis interpretation is based on mineral loadings and composition only;",
      "no axis is selected because of downstream microbial, P-functional or SEM significance."
    )
  )
)

openxlsx::write.xlsx(
  list(
    Summary = summary_table,
    Component_QC = component_qc,
    PCA_Variance = variance_table,
    PCA_Loadings = loading_table,
    Sample_Scores = score_table,
    Associations = association_table,
    Group_Contrasts = group_table,
    CLR_matrix = data.frame(SampleID = rownames(X_clr), X_clr, check.names = FALSE)
  ),
  file = file.path(OUT_DIR, "XRD_CLR_PCA_stage1_results.xlsx"),
  overwrite = TRUE
)

saveRDS(
  list(
    mineral_columns = mineral_cols,
    X_raw = X,
    X_prop = X_prop,
    X_czm = X_czm,
    X_clr = X_clr,
    pca_fit = pca_fit,
    oriented_scores = scores,
    oriented_loadings = loadings,
    variance = variance,
    sample_ids = dat$station,
    groups = dat$Group
  ),
  file.path(OUT_DIR, "XRD_CLR_PCA_global_basis.rds")
)

writeLines(capture.output(sessionInfo()), file.path(OUT_DIR, "sessionInfo.txt"))

cat("Stage-1 XRD CLR-PCA diagnostic completed.\n")
cat(sprintf("PC1 = %.4f%%; PC2 = %.4f%%; cumulative = %.4f%%\n",
            100*variance[1], 100*variance[2], 100*sum(variance[1:2])))

## Audit against the genuine saved 2026-10-07 historical intermediate.
ref <- saved_scores[match(dat$station, saved_scores$SampleID), ]
stopifnot(identical(as.character(ref$SampleID), as.character(dat$station)))
score_diff <- max(abs(score_table$PC1 - ref$PC1), na.rm = TRUE)
var_ref <- read.csv(file.path("data", "mineral", "historical_CZM_CLR_PCA_variance.csv"), fileEncoding = "UTF-8-BOM")
variance_diff <- abs(variance[1] - as.numeric(var_ref$Variance_explained[1]))
cat(sprintf("Historical PC1 max score difference: %.12g; PCA variance difference %.12g\n", score_diff, variance_diff))
if (score_diff > 1e-7 || variance_diff > 1e-7) stop("Historical CZM replay FAILS source-score audit; check R/zCompositions versions and input")
write.csv(data.frame(SampleID=dat$station, PC1=score_table$PC1, PC2=score_table$PC2,
                      PC3=score_table$PC3),file.path(OUT_DIR, "CZM_recalculated_PC_scores.csv"),row.names=FALSE)
write.csv(data.frame(SampleID=rownames(X_clr), X_clr,check.names=FALSE),
          file.path(OUT_DIR, "CZM_75x10_CLR_matrix.csv"),row.names=FALSE)
cat("Historical CZM PCA independent R numerical audit PASS.\n")

## New reproducible clustering sensitivity diagnostic (not a recovered historical
## clustering script): Ward.D2 clustering in CLR/Aitchison Euclidean space.
clust_new <- cutree(hclust(dist(X_clr), method = "ward.D2"), k=2)
reference <- as.integer(dat$Group)
if (sum(clust_new != reference) > sum((3-clust_new) != reference)) clust_new <- 3-clust_new
ct <- table(reference, clust_new)
choose2 <- function(x) x*(x-1)/2
nij <- sum(choose2(ct))
a <- sum(choose2(rowSums(ct)))
b <- sum(choose2(colSums(ct)))
total_pairs <- choose2(sum(ct))
ARI <- (nij - a*b/total_pairs)/(0.5*(a+b)-a*b/total_pairs)
reassign <- sum(clust_new != reference)
write.csv(data.frame(SampleID=dat$station, Operational_class=reference,
                     CZM_CLR_WardD2_class=clust_new, Class_changed=clust_new!=reference),
          file.path(OUT_DIR, "CZM_CLR_WardD2_classification.csv"),row.names=FALSE)
write.csv(data.frame(ARI=ARI,N_reassigned=reassign,
                     N=length(reference),Method="CZM CLR Euclidean + Ward.D2"),
          file.path(OUT_DIR, "CZM_CLR_WardD2_sensitivity.csv"),row.names=FALSE)
cat(sprintf("CZM/Ward.D2 sensitivity: ARI %.6g; %d reassigned of 75.\n",ARI,reassign))
if (round(ARI, 3) == 0.570 && reassign == 9L) {
  cat("CZM clustering agrees with manuscript at reported precision: ARI=0.570; 9 reassignments.\n")
} else {
  warning(sprintf("CZM clustering differs from manuscript: ARI=%.6f, changed=%d", ARI, reassign))
}
