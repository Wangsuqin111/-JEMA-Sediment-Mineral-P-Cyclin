import zipfile, xml.etree.ElementTree as ET, re, math, json, os, csv, gzip, shutil
from pathlib import Path
import numpy as np
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.sandwich_covariance import cov_hc3

BASE=Path(__file__).resolve().parent.parent
OUTDIR=BASE/'outputs'/'fig06'
OUTDIR.mkdir(exist_ok=True,parents=True)
SEED=20261007
BOOT_N=999
rng_global=np.random.default_rng(SEED)

def fnum(x):
    try: return float(x)
    except: return np.nan

def z(x):
    x=np.asarray(x,dtype=float)
    return (x-np.mean(x))/np.std(x,ddof=1)

def ols(y, X_names, data):
    yy=z([d[y] for d in data])
    X=np.column_stack([z([d[x] for d in data]) for x in X_names]) if X_names else np.empty((len(data),0))
    Xc=sm.add_constant(X,has_constant='add')
    m=sm.OLS(yy,Xc).fit()
    return m

def fit_path(data, final_response='PFunction'):
    eqs={
        'Mineral': ('Mineral',['Hydro']),
        'Water': ('Water',['Hydro','Mineral']),
        'Sediment': ('Sediment',['Hydro','Mineral']),
        'Microbial': ('Microbial',['Mineral','Water','Sediment']),
        'PFunction': (final_response,['Hydro','Water','Sediment','Microbial']),
    }
    models={}; paths=[]; r2=[]
    for target,(resp,preds) in eqs.items():
        m=ols(resp,preds,data); models[target]=m
        for i,p in enumerate(preds, start=1):
            paths.append({'From':p,'To':target,'Path':f'{p} -> {target}','Beta':float(m.params[i]),'OLS_SE':float(m.bse[i]),'OLS_P':float(m.pvalues[i])})
        r2.append({'Node':target,'R2':float(m.rsquared),'Adjusted_R2':float(m.rsquared_adj)})
    order=['Hydro -> Mineral','Hydro -> Water','Mineral -> Water','Hydro -> Sediment','Mineral -> Sediment','Mineral -> Microbial','Water -> Microbial','Sediment -> Microbial','Hydro -> PFunction','Water -> PFunction','Sediment -> PFunction','Microbial -> PFunction']
    paths=sorted(paths,key=lambda q:order.index(q['Path']))
    return {'models':models,'paths':paths,'r2':r2}

def fit_full_mediation(data, final_response='PFunction'):
    eqs={
        'Mineral': ('Mineral',['Hydro']),
        'Water': ('Water',['Hydro','Mineral']),
        'Sediment': ('Sediment',['Hydro','Mineral']),
        'Microbial': ('Microbial',['Mineral','Water','Sediment']),
        'PFunction': (final_response,['Water','Sediment','Microbial']),
    }
    models={}
    for target,(resp,preds) in eqs.items(): models[target]=ols(resp,preds,data)
    return models

def get_coef_p(resp, test_pred, conditioning_preds, data):
    m=ols(resp,conditioning_preds+[test_pred],data)
    return float(m.params[-1]), float(m.pvalues[-1])

def dsep_direct(data, final_response='PFunction'):
    claims=[]
    est,p=get_coef_p('Microbial','Hydro',['Mineral','Water','Sediment'],data); claims.append(('Microbial ~ Hydro | Mineral+Water+Sediment',est,p))
    est,p=get_coef_p(final_response,'Mineral',['Hydro','Water','Sediment','Microbial'],data); claims.append((f'{final_response} ~ Mineral | Hydro+Water+Sediment+Microbial',est,p))
    est,p=get_coef_p('Sediment','Water',['Hydro','Mineral'],data); claims.append(('Sediment ~ Water | Hydro+Mineral',est,p))
    C=-2*sum(math.log(max(p,1e-300)) for _,_,p in claims); df=2*len(claims); P=float(stats.chi2.sf(C,df))
    return claims,C,df,P

def dsep_full_mediation(data, final_response='PFunction'):
    claims=[]
    est,p=get_coef_p('Microbial','Hydro',['Mineral','Water','Sediment'],data); claims.append(('Microbial ~ Hydro | Mineral+Water+Sediment',est,p))
    est,p=get_coef_p(final_response,'Mineral',['Hydro','Water','Sediment','Microbial'],data); claims.append((f'{final_response} ~ Mineral | Hydro+Water+Sediment+Microbial',est,p))
    est,p=get_coef_p(final_response,'Hydro',['Water','Sediment','Microbial'],data); claims.append((f'{final_response} ~ Hydro | Water+Sediment+Microbial',est,p))
    est,p=get_coef_p('Sediment','Water',['Hydro','Mineral'],data); claims.append(('Sediment ~ Water | Hydro+Mineral',est,p))
    C=-2*sum(math.log(max(p,1e-300)) for _,_,p in claims); df=2*len(claims); P=float(stats.chi2.sf(C,df))
    return claims,C,df,P

def named_indirects(paths):
    b={(r['From'],r['To']):r['Beta'] for r in paths}
    get=lambda a,c:b[(a,c)]
    return {
      'Hydro -> Water -> Microbial -> PFunction':get('Hydro','Water')*get('Water','Microbial')*get('Microbial','PFunction'),
      'Hydro -> Mineral -> Water -> Microbial -> PFunction':get('Hydro','Mineral')*get('Mineral','Water')*get('Water','Microbial')*get('Microbial','PFunction'),
      'Hydro -> Sediment -> Microbial -> PFunction':get('Hydro','Sediment')*get('Sediment','Microbial')*get('Microbial','PFunction'),
      'Hydro -> Mineral -> Sediment -> Microbial -> PFunction':get('Hydro','Mineral')*get('Mineral','Sediment')*get('Sediment','Microbial')*get('Microbial','PFunction'),
      'Mineral -> Water -> Microbial -> PFunction':get('Mineral','Water')*get('Water','Microbial')*get('Microbial','PFunction'),
      'Mineral -> Sediment -> Microbial -> PFunction':get('Mineral','Sediment')*get('Sediment','Microbial')*get('Microbial','PFunction'),
      'Mineral -> Microbial -> PFunction':get('Mineral','Microbial')*get('Microbial','PFunction'),
    }

def total_effects(paths):
    nodes=['Hydro','Mineral','Water','Sediment','Microbial','PFunction']; idx={n:i for i,n in enumerate(nodes)}
    B=np.zeros((6,6))
    for r in paths:B[idx[r['From']],idx[r['To']]]=r['Beta']
    T=B.copy(); power=B.copy()
    for _ in range(2,6): power=power@B; T+=power
    out=[]
    for p in nodes[:-1]:
        i=idx[p]; j=idx['PFunction']; out.append({'Predictor':p,'Direct_effect':float(B[i,j]),'Indirect_effect':float(T[i,j]-B[i,j]),'Total_effect':float(T[i,j])})
    return out

def _fast_fit_betas_r2(data, final_response='PFunction'):
    vars_order=['Hydro','Mineral','Water','Sediment','Microbial',final_response]
    A=np.array([[float(d[v]) for v in vars_order] for d in data],dtype=float)
    # R scale(): sample SD (ddof=1)
    Z=(A-A.mean(axis=0))/A.std(axis=0,ddof=1)
    H,M,W,S,Mi,F=[Z[:,i] for i in range(6)]
    specs=[
        ('Mineral',M,[H],['Hydro']),
        ('Water',W,[H,M],['Hydro','Mineral']),
        ('Sediment',S,[H,M],['Hydro','Mineral']),
        ('Microbial',Mi,[M,W,S],['Mineral','Water','Sediment']),
        ('PFunction',F,[H,W,S,Mi],['Hydro','Water','Sediment','Microbial'])
    ]
    pmap={};rmap={}
    for target,y,xcols,preds in specs:
        X=np.column_stack([np.ones(len(y))]+xcols)
        coef=np.linalg.lstsq(X,y,rcond=None)[0]
        yh=X@coef; ssr=np.sum((y-yh)**2); sst=np.sum((y-y.mean())**2)
        rmap[target]=1-ssr/sst if sst>0 else np.nan
        for j,pred in enumerate(preds,start=1): pmap[f'{pred} -> {target}']=float(coef[j])
    return pmap,rmap

def boot_model(data, final_response='PFunction', n_boot=999, seed=1):
    main=fit_path(data,final_response); pathnames=[r['Path'] for r in main['paths']]; nodes=[r['Node'] for r in main['r2']]; inds=list(named_indirects(main['paths']).keys())
    rng=np.random.default_rng(seed); n=len(data)
    bd={p:np.full(n_boot,np.nan) for p in pathnames}; rd={x:np.full(n_boot,np.nan) for x in nodes}; idraw={x:np.full(n_boot,np.nan) for x in inds}
    valid=0
    for b in range(n_boot):
        idxs=rng.integers(0,n,size=n); db=[data[i] for i in idxs]
        try:
            pmap,rmap=_fast_fit_betas_r2(db,final_response)
            # indirects from beta map
            class X: pass
            fake=[]
            for path,beta in pmap.items():
                fr,to=path.split(' -> '); fake.append({'From':fr,'To':to,'Path':path,'Beta':beta})
            imap=named_indirects(fake)
            if not all(np.isfinite(list(pmap.values())+list(rmap.values())+list(imap.values()))): continue
            for k in bd:bd[k][b]=pmap[k]
            for k in rd:rd[k][b]=rmap[k]
            for k in idraw:idraw[k][b]=imap[k]
            valid+=1
        except Exception: pass
    def clean(a): return np.asarray(a)[np.isfinite(a)]
    def ci(a):
        a=clean(a); return float(np.quantile(a,.025)),float(np.quantile(a,.975))
    def bp(a):
        a=clean(a); return float(min(1,2*min((np.sum(a<=0)+1)/(len(a)+1),(np.sum(a>=0)+1)/(len(a)+1))))
    paths=[]; mainmap={r['Path']:r for r in main['paths']}
    for k in pathnames:
        arr=clean(bd[k]);lo,hi=ci(arr);r=mainmap[k].copy();r.update({'Boot_N':len(arr),'Boot_SE':float(np.std(arr,ddof=1)),'CI_low':lo,'CI_high':hi,'Boot_P':bp(arr),'Supported':bool(lo>0 or hi<0)});paths.append(r)
    r2=[];mainr={r['Node']:r for r in main['r2']}
    for k in nodes:
        arr=clean(rd[k]);lo,hi=ci(arr);r=mainr[k].copy();r.update({'Boot_N':len(arr),'CI_low':lo,'CI_high':hi});r2.append(r)
    indsout=[];maini=named_indirects(main['paths'])
    for k in inds:
        arr=clean(idraw[k]);lo,hi=ci(arr);indsout.append({'Indirect_path':k,'Effect':float(maini[k]),'Boot_N':len(arr),'CI_low':lo,'CI_high':hi,'Boot_P':bp(arr),'Supported':bool(lo>0 or hi<0)})
    return {'main':main,'paths':paths,'r2':r2,'indirects':indsout,'valid':valid,'beta_draws':{k:clean(v).tolist() for k,v in bd.items()},'r2_draws':{k:clean(v).tolist() for k,v in rd.items()},'indirect_draws':{k:clean(v).tolist() for k,v in idraw.items()}}

# ---------- Load and merge from ARTICLE-SPECIFIC PROCESSED INPUTS ----------
# The upstream spreadsheets are intentionally NOT distributed. This processed
# 61-sample table holds exactly the original fitted composite scores.
REPO=Path(__file__).resolve().parent.parent
with (REPO/'data/path_model/path_composite_scores_61.csv').open(encoding='utf-8-sig',newline='') as f:
    sem=[dict(r) for r in csv.DictReader(f)]
# The model functions operate on float-able strings; ensure all numeric fields
# retain the original numeric precision provided in the processed public table.
for d in sem:
    for k,v in list(d.items()):
        if k not in ('SampleID','Habitat') and v!='': d[k]=fnum(v)
assert len(sem)==61
assert sum(d['Habitat']=='Clay-enriched habitat' for d in sem)==38
assert sum(d['Habitat']=='Clay-depleted habitat' for d in sem)==23

with (REPO/'data/mineral/XRD_mineral_assemblages_75.csv').open(encoding='utf-8-sig',newline='') as f:
    minerals_75=[dict(r) for r in csv.DictReader(f)]
with (REPO/'data/mineral/modelled_BSS_75site_crosswalk_70_valid.csv').open(encoding='utf-8-sig',newline='') as f:
    bss_map={r['SampleID']: fnum(r['BSS_authoritative']) for r in csv.DictReader(f)}
xrd_map={}
for r in minerals_75:
    sid=r['SampleID']; v={k:fnum(r[k]) for k in ['石英','伊利石','钠长石','白云母','斜绿泥石','高岭石','钾长石','方解石','白云石','绿泥石']}
    cl=v['伊利石']+v['高岭石']+v['斜绿泥石']+v['绿泥石']
    fw=v['石英']+v['钠长石']+v['钾长石']
    v.update({'剪切力':bss_map.get(sid,float('nan')),'维度':fnum(r['维度']),'经度':fnum(r['经度'])})
    xrd_map[sid]={**v,'SampleID':sid,'Group':int(r['Group']),'Clay_related_sum':cl,'Framework_sum':fw,'SLR':float(np.log(cl/fw)),
        'SLR_no_clinochlore':fnum(r['SLR_no_clinochlore']),'SLR_no_chlorite':fnum(r['SLR_no_chlorite']),
        'SLR_with_muscovite':fnum(r['SLR_with_muscovite']),'PC1':fnum(r['PC1']),'PC2':fnum(r['PC2'])}

# ---------- Primary whole-system ----------
whole=boot_model(sem,n_boot=BOOT_N,seed=1001)
claims,C,df,Fp=dsep_direct(sem)
fmclaims,fmC,fmdf,fmP=dsep_full_mediation(sem)
whole['dsep']=[{'Claim':a,'Estimate':b,'P_value':p} for a,b,p in claims]
whole['fisher']={'C':C,'df':df,'P':Fp}; whole['full_mediation_fisher']={'C':fmC,'df':fmdf,'P':fmP}
whole['total_effects']=total_effects(whole['main']['paths'])

# ---------- Subgroups ----------
enr=[d for d in sem if d['Habitat']=='Clay-enriched habitat']; dep=[d for d in sem if d['Habitat']=='Clay-depleted habitat']
enrb=boot_model(enr,n_boot=BOOT_N,seed=2001); depb=boot_model(dep,n_boot=BOOT_N,seed=3001)
for obj,data in [(enrb,enr),(depb,dep)]:
    cl,cc,dd,pp=dsep_direct(data);obj['fisher']={'C':cc,'df':dd,'P':pp}

# group path diffs: independently resampled per group; paired by bootstrap iteration
pathnames=[r['Path'] for r in whole['paths']]
gdiff=[]
for p in pathnames:
    a=np.asarray(enrb['beta_draws'][p]); b=np.asarray(depb['beta_draws'][p]); n=min(len(a),len(b)); x=b[:n]-a[:n]
    lo,hi=np.quantile(x,[.025,.975]); bp=min(1,2*min((np.sum(x<=0)+1)/(n+1),(np.sum(x>=0)+1)/(n+1)))
    ea=next(r['Beta'] for r in enrb['paths'] if r['Path']==p); db=next(r['Beta'] for r in depb['paths'] if r['Path']==p)
    gdiff.append({'Path':p,'Beta_enriched':ea,'Beta_depleted':db,'Difference_depleted_minus_enriched':db-ea,'Boot_N':n,'CI_low':float(lo),'CI_high':float(hi),'Boot_P':float(bp),'Supported_difference':bool(lo>0 or hi<0)})

# ---------- Process-specific sensitivity ----------
process_map={'P_OP':'Organic P mineralization','P_IP':'Inorganic P solubilization','P_TP':'P uptake and transport','P_RG':'P-starvation response regulation'}
proc_paths=[];proc_r2=[];proc_fisher=[];proc_ind=[]
for i,(var,name) in enumerate(process_map.items()):
    obj=boot_model(sem,final_response=var,n_boot=BOOT_N,seed=5001+i)
    cl,cc,dd,pp=dsep_direct(sem,final_response=var)
    proc_fisher.append({'P_process':name,'Fisher_C':cc,'Fisher_df':dd,'Fisher_P':pp,'Valid_bootstrap_N':obj['valid']})
    for r in obj['paths']: rr=r.copy();rr['P_process']=name;proc_paths.append(rr)
    for r in obj['r2']: rr=r.copy();rr['P_process']=name;proc_r2.append(rr)
    for r in obj['indirects']: rr=r.copy();rr['P_process']=name;proc_ind.append(rr)

# ---------- Alternative mineral definitions (internal robustness) ----------
def run_mineral_variant(key,label,seed):
    dd=[]
    for d in sem:
        q=d.copy();q['Mineral']=d[key];dd.append(q)
    obj=boot_model(dd,n_boot=BOOT_N,seed=seed); cl,cc,dfi,pp=dsep_direct(dd)
    pmap={r['Path']:r for r in obj['paths']}; rmap={r['Node']:r for r in obj['r2']}
    return {'Definition':label,'Fisher_C':cc,'Fisher_df':dfi,'Fisher_P':pp,'Hydro_to_Mineral_Beta':pmap['Hydro -> Mineral']['Beta'],'Hydro_to_Mineral_CI_low':pmap['Hydro -> Mineral']['CI_low'],'Hydro_to_Mineral_CI_high':pmap['Hydro -> Mineral']['CI_high'],'Mineral_to_Water_Beta':pmap['Mineral -> Water']['Beta'],'Mineral_to_Microbial_Beta':pmap['Mineral -> Microbial']['Beta'],'Mineral_R2':rmap['Mineral']['R2'],'Microbial_R2':rmap['Microbial']['R2'],'PFunction_R2':rmap['PFunction']['R2']}

min_sens=[]
for key,label,seed in [
 ('Mineral','Primary SLR: (Illite+Kaolinite+Clinochlore+Chlorite)/(Quartz+Albite+Orthoclase)',7001),
 ('SLR_with_muscovite','Legacy-like sensitivity: include Muscovite in numerator',7004),
 ('OldMineral','Previous published-run mineral score',7005),
 ('Mineral_PC1','10-part CLR-PCA PC1',7006),
 ('Mineral_PC2','10-part CLR-PCA PC2',7007),
]: min_sens.append(run_mineral_variant(key,label,seed))

# ---------- Robust diagnostics ----------
core=whole['main']
diagnostics=[]
for resp,m in core['models'].items():
    resid=m.resid; exog=m.model.exog
    sh_p=float(stats.shapiro(resid).pvalue) if len(resid)<=5000 else np.nan
    bp=het_breuschpagan(resid,exog); bp_p=float(bp[1])
    infl=m.get_influence(); cooks=np.asarray(infl.cooks_distance[0])
    cov=cov_hc3(m); se=np.sqrt(np.diag(cov)); t=m.params/se; p=2*stats.t.sf(np.abs(t),df=m.df_resid)
    names=['Intercept']+m.model.exog_names[1:]
    preds=[r['From'] for r in core['paths'] if r['To']==resp]
    # VIF predictor values
    if exog.shape[1]<=2: vifs={preds[0]:1.0} if preds else {}
    else: vifs={preds[j-1]:float(variance_inflation_factor(exog,j)) for j in range(1,exog.shape[1])}
    for j,pred in enumerate(preds,start=1):
        diagnostics.append({'Response':resp,'Predictor':pred,'R2':float(m.rsquared),'Adjusted_R2':float(m.rsquared_adj),'Residual_Shapiro_P':sh_p,'Breusch_Pagan_P':bp_p,'Max_Cooks_D':float(np.max(cooks)),'N_Cooks_D_above_4_over_N':int(np.sum(cooks>4/len(resid))),'VIF':vifs.get(pred,np.nan),'HC3_SE':float(se[j]),'HC3_t':float(t[j]),'HC3_P':float(p[j])})

# LOO
loo_rows=[]
fullbet={r['Path']:r['Beta'] for r in whole['paths']}
for i,dout in enumerate(sem):
    dd=sem[:i]+sem[i+1:]
    f=fit_path(dd)
    for r in f['paths']:loo_rows.append({'Omitted_sample':dout['SampleID'],'Path':r['Path'],'Beta_LOO':r['Beta']})
loo_summary=[]
for p in pathnames:
    vals=np.array([r['Beta_LOO'] for r in loo_rows if r['Path']==p]); changes=np.abs(vals-fullbet[p]); imax=int(np.argmax(changes))
    sub=[r for r in loo_rows if r['Path']==p]
    loo_summary.append({'Path':p,'Beta_full':fullbet[p],'LOO_min':float(vals.min()),'LOO_max':float(vals.max()),'LOO_median':float(np.median(vals)),'Max_absolute_change':float(changes.max()),'Max_influence_sample':sub[imax]['Omitted_sample'],'Sign_consistency':float(np.mean(np.sign(vals)==np.sign(fullbet[p]))),'Stable_direction_90pct':bool(np.mean(np.sign(vals)==np.sign(fullbet[p]))>=.9)})

# Spatial residual Moran I, symmetric k=4

def moran_perm(vals,x,y,k=4,perm=999,seed=1):
    vals=np.asarray(vals,float);coords=np.column_stack([x,y]).astype(float); keep=np.all(np.isfinite(coords),axis=1)&np.isfinite(vals);vals=vals[keep];coords=coords[keep];n=len(vals)
    dist=np.sqrt(((coords[:,None,:]-coords[None,:,:])**2).sum(axis=2));np.fill_diagonal(dist,np.inf);W=np.zeros((n,n))
    for i in range(n): W[i,np.argsort(dist[i])[:min(k,n-1)]]=1
    W=((W+W.T)>0).astype(float); S0=W.sum(); zc=vals-vals.mean()
    def stat(zv): return (n/S0)*((W*np.outer(zv,zv)).sum()/(zv*zv).sum())
    obs=stat(zc); rng=np.random.default_rng(seed); sims=np.array([stat(rng.permutation(zc)) for _ in range(perm)]);p=(np.sum(np.abs(sims)>=abs(obs))+1)/(perm+1)
    return n,float(obs),float(p)
spatial=[]
coords_x=[d['Longitude'] for d in sem];coords_y=[d['Latitude'] for d in sem]
for j,(resp,m) in enumerate(core['models'].items()):
    n,mi,p=moran_perm(m.resid,coords_x,coords_y,seed=6001+j);spatial.append({'Response':resp,'N':n,'Moran_I':mi,'Permutation_P':p,'Neighborhood':'symmetric 4-nearest-neighbor'})

# ---------- XRD-level correlations and class contrast ----------
allx=list(xrd_map.values())
slr=[r['SLR'] for r in allx]; shear=[r['剪切力'] for r in allx]
rho,p=stats.spearmanr(slr,shear,nan_policy='omit')
g1=np.array([r['SLR'] for r in allx if int(float(r['Group']))==1]);g2=np.array([r['SLR'] for r in allx if int(float(r['Group']))==2])
U,pgrp=stats.mannwhitneyu(g1,g2,alternative='two-sided');delta=(2*U/(len(g1)*len(g2))-1)
# correlations among mineral representations
repr_corr=[]
keys=['SLR','SLR_no_clinochlore','SLR_no_chlorite','SLR_with_muscovite','PC1','PC2']
for a in keys:
 for b in keys:
  if keys.index(b)<=keys.index(a): continue
  rr,pp=stats.spearmanr([r[a] for r in allx],[r[b] for r in allx],nan_policy='omit');repr_corr.append({'Representation_A':a,'Representation_B':b,'Spearman_rho':float(rr),'P_value':float(pp)})

# ---------- Sample audit ----------
audit=[
 {'Analysis_set':'XRD samples','N':len(allx)},
 {'Analysis_set':'SEM complete samples','N':len(sem)},
 {'Analysis_set':'Clay-enriched SEM samples','N':len(enr)},
 {'Analysis_set':'Clay-depleted SEM samples','N':len(dep)},
 {'Analysis_set':'Whole-system valid bootstrap iterations','N':whole['valid']},
 {'Analysis_set':'Clay-enriched valid bootstrap iterations','N':enrb['valid']},
 {'Analysis_set':'Clay-depleted valid bootstrap iterations','N':depb['valid']},
]

# ---------- CSV exports ----------
def write_csv(path, rows):
    if not rows: return
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields:fields.append(k)
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

sem_export=[]
for d in sem:
    sem_export.append({k:d[k] for k in ['SampleID','Habitat','Hydro','Mineral','Water','Sediment','Microbial','PFunction','P_OP','P_IP','P_TP','P_RG','OldMineral','Mineral_PC1','Mineral_PC2','SLR_no_clinochlore','SLR_no_chlorite','SLR_with_muscovite','Bed_shear_raw','Latitude','Longitude'] if k in d})
xrd_export=[]
for r in allx:
    xrd_export.append({k:r.get(k) for k in ['SampleID','Group','石英','伊利石','钠长石','白云母','斜绿泥石','高岭石','钾长石','方解石','白云石','绿泥石','Clay_related_sum','Framework_sum','SLR','SLR_no_clinochlore','SLR_no_chlorite','SLR_with_muscovite','PC1','PC2','剪切力','维度','经度']})

write_csv(OUTDIR/'derived_mineral_indices_75.csv',xrd_export)
write_csv(OUTDIR/'SEM_analysis_dataset_61.csv',sem_export)
write_csv(OUTDIR/'whole_system_paths.csv',whole['paths'])
write_csv(OUTDIR/'whole_system_R2.csv',whole['r2'])
write_csv(OUTDIR/'whole_system_dsep.csv',whole['dsep'])
write_csv(OUTDIR/'whole_system_indirect_effects.csv',whole['indirects'])
write_csv(OUTDIR/'whole_system_total_effects.csv',whole['total_effects'])
write_csv(OUTDIR/'group_path_differences.csv',gdiff)
write_csv(OUTDIR/'process_specific_paths.csv',proc_paths)
write_csv(OUTDIR/'process_specific_R2.csv',proc_r2)
write_csv(OUTDIR/'process_specific_fit.csv',proc_fisher)
write_csv(OUTDIR/'process_specific_indirect_effects.csv',proc_ind)
write_csv(OUTDIR/'mineral_definition_sensitivity.csv',min_sens)
write_csv(OUTDIR/'mineral_representation_correlations.csv',repr_corr)
write_csv(OUTDIR/'whole_system_diagnostics.csv',diagnostics)
write_csv(OUTDIR/'whole_system_LOO.csv',loo_summary)
write_csv(OUTDIR/'whole_system_spatial_residuals.csv',spatial)
write_csv(OUTDIR/'sample_audit.csv',audit)

# full bootstrap draws compressed
for name,draws in [('whole_path_beta_bootstrap',whole['beta_draws']),('whole_R2_bootstrap',whole['r2_draws']),('whole_indirect_bootstrap',whole['indirect_draws'])]:
    fields=list(draws.keys()); n=max(len(draws[k]) for k in fields)
    with gzip.open(OUTDIR/f'{name}.csv.gz','wt',encoding='utf-8',newline='') as f:
        w=csv.writer(f);w.writerow(fields)
        for i in range(n):w.writerow([draws[k][i] if i<len(draws[k]) else '' for k in fields])

# group results consolidated
for label,obj in [('Clay_enriched',enrb),('Clay_depleted',depb)]:
    write_csv(OUTDIR/f'{label}_paths.csv',obj['paths']);write_csv(OUTDIR/f'{label}_R2.csv',obj['r2'])

# JSON master
master={
 'metadata':{'analysis_date':'2026-10-07','primary_mineral_definition':'ln[(Illite + Kaolinite + Clinochlore + Chlorite)/(Quartz + Albite + Orthoclase)]','N_XRD':len(allx),'N_SEM':len(sem),'bootstrap_n':BOOT_N,'interpretation':'association-based; P-functional potential, not process rates'},
 'sample_audit':audit,
 'XRD_level_summary':{'SLR_vs_bed_shear_Spearman_rho':float(rho),'P_value':float(p),'Clay_enriched_vs_depleted_Cliffs_delta':float(delta),'Mann_Whitney_P':float(pgrp)},
 'whole_system':{'Fisher_C':C,'Fisher_df':df,'Fisher_P':Fp,'full_mediation_Fisher_C':fmC,'full_mediation_df':fmdf,'full_mediation_P':fmP,'paths':whole['paths'],'R2':whole['r2'],'dsep':whole['dsep'],'indirects':whole['indirects'],'total_effects':whole['total_effects']},
 'groups':{'Clay_enriched':{'Fisher':enrb['fisher'],'paths':enrb['paths'],'R2':enrb['r2']},'Clay_depleted':{'Fisher':depb['fisher'],'paths':depb['paths'],'R2':depb['r2']},'path_differences':gdiff},
 'process_specific':{'fit':proc_fisher,'paths':proc_paths,'R2':proc_r2,'indirects':proc_ind},
 'mineral_definition_sensitivity':min_sens,
 'mineral_representation_correlations':repr_corr,
 'diagnostics':diagnostics,
 'LOO':loo_summary,
 'spatial_residuals':spatial
}
with open(OUTDIR/'MASTER_RESULTS.json','w',encoding='utf-8') as f:json.dump(master,f,ensure_ascii=False,indent=2)

# concise summary text
supported=[r for r in whole['paths'] if r['Supported']]
with open(OUTDIR/'ANALYSIS_SUMMARY.txt','w',encoding='utf-8') as f:
    f.write('FINAL SLR PIECEWISE SEM ANALYSIS — 2026-10-07\n\n')
    f.write(f'Primary mineral SLR = ln[(Illite + Kaolinite + Clinochlore + Chlorite)/(Quartz + Albite + Orthoclase)]\n')
    f.write(f'XRD n={len(allx)}; SEM n={len(sem)}; enriched={len(enr)}; depleted={len(dep)}\n')
    f.write(f'SLR vs bed shear: Spearman rho={rho:.4f}, P={p:.3g}\n')
    f.write(f'Whole-system: Fisher C={C:.4f}, df={df}, P={Fp:.4f}; full mediation Fisher C={fmC:.4f}, df={fmdf}, P={fmP:.4g}\n\n')
    f.write('Supported whole-system paths (95% fixed-score bootstrap CI excludes zero):\n')
    for r in supported:f.write(f"- {r['Path']}: beta={r['Beta']:.4f}, 95% CI [{r['CI_low']:.4f}, {r['CI_high']:.4f}]\n")
    f.write('\nR2:\n')
    for r in whole['r2']:f.write(f"- {r['Node']}: {r['R2']:.4f} [{r['CI_low']:.4f}, {r['CI_high']:.4f}]\n")
    f.write('\nProcess-specific sensitivity fit:\n')
    for r in proc_fisher:f.write(f"- {r['P_process']}: Fisher C={r['Fisher_C']:.4f}, P={r['Fisher_P']:.4f}\n")
    f.write('\nPrimary interpretation remains association-based. Signs of PC/ordination-derived nodes depend on axis orientation; do not interpret a negative Microbial -> PFunction coefficient as biological suppression without inspecting loadings/orientation.\n')

print(json.dumps({'whole_Fisher_C':C,'whole_Fisher_P':Fp,'full_mediation_Fisher_P':fmP,'supported_paths':[r['Path'] for r in supported],'process_fit':proc_fisher,'mineral_sensitivity':min_sens},ensure_ascii=False,indent=2))
