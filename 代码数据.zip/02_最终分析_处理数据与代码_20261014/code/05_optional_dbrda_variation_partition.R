# Publication-method analysis: Bray-Curtis distance-based variation partition
# Reproduces code from processed input boundary, using HISTORICAL recovered CZM.
# Requires R packages: vegan, permute. This script requires running 01_recovered_CZM_CLR_PCA.R FIRST.
# R-run results supplied and cross-checked by researchers on 2026-10-14.
# This packaging environment lacks R; verify_replay.py checks archived output values,
# and this source allows independent re-execution on a system with R installed.

suppressPackageStartupMessages(library(vegan))

root <- "."
outdir <- file.path(root,"results","varpart_optional_dbrda_CZM")
dir.create(outdir,recursive=TRUE,showWarnings=FALSE)
XRD <- read.csv("data/mineral/XRD_mineral_assemblages_75.csv",check.names=FALSE,fileEncoding="UTF-8-BOM")
EV <- read.csv("data/environment/environment_75_analysis_variables.csv",check.names=FALSE,fileEncoding="UTF-8-BOM")
MT <- read.csv("data/microbiome/sediment_metadata_71.csv",check.names=FALSE)
G <- read.delim(gzfile("data/microbiome/genus_abundance_71.tsv.gz"),check.names=FALSE)
clr_path <- "results/CZM_CLR_R/CZM_75x10_CLR_matrix.csv"
if (!file.exists(clr_path)) stop("First run: Rscript code/01_recovered_CZM_CLR_PCA.R")
MC <- read.csv(clr_path,check.names=FALSE)
# Column headers in the processed CSV may have been trimmed by R/Windows.
# Resolve only exact semantic matches after normalising whitespace and micro symbols.
# Do not silently substitute a different physicochemical variable.
normalise_header <- function(x) {
  x <- enc2utf8(as.character(x))
  x <- gsub("[[:space:]\u00A0]+", "", x, perl=TRUE)
  x <- gsub("\u00B5", "\u03BC", x, fixed=TRUE) # micro sign -> Greek mu
  x
}
resolve_headers <- function(dat, requested, block_name) {
  actual <- names(dat)
  norm_actual <- normalise_header(actual)
  matched <- vapply(requested, function(key) {
    hits <- which(norm_actual == normalise_header(key))
    if (length(hits) != 1L) {
      stop(sprintf("%s column not uniquely found: <%s>. Actual names: %s",
                   block_name, key, paste(sprintf("<%s>", actual), collapse=", ")))
    }
    actual[hits]
  }, character(1))
  cat(sprintf("Matched %s columns (%d): %s\n",
              block_name, length(matched), paste(matched, collapse=" | ")))
  unname(matched)
}
watercols <- resolve_headers(EV,
  c("Temp","DO(mg/L)","pH","SPC(-μs/cm)","NTU","Chl(μg/L)","fDOMQSU","DEP(m)"),
  "water")
sedcols <- resolve_headers(EV,
  c("有机碳", "全氮", "全磷", "微生物碳", "微生物氮", "微生物磷", "含水率"),
  "sediment")
mineralcols <- c("石英","伊利石","钠长石","白云母","斜绿泥石","高岭石","钾长石","方解石","白云石","绿泥石")
stopifnot(nrow(MT)==71, all(grepl("-ni$",MT$SampleID)),nrow(XRD)==75)
# strictly keep sediment metagenomes and complete environmental cases
valid <- MT$Mineral_SampleID[MT$Mineral_SampleID %in% EV$station]
valid <- valid[complete.cases(EV[match(valid,EV$station),c(watercols,sedcols)])]
stopifnot(length(valid)==70, !anyDuplicated(valid))
sampleIDs <- MT$SampleID[match(valid,MT$Mineral_SampleID)]
if (!all(sampleIDs %in% names(G))) stop("Missing genus sample columns")
if (anyNA(match(valid, MC$SampleID))) stop("Missing mineral IDs in recovered CZM matrix")
Y <- t(as.matrix(G[,sampleIDs,drop=FALSE]));storage.mode(Y) <- "numeric"
if (any(!is.finite(Y)) || any(rowSums(Y) <= 0)) stop("Genus matrix invalid or empty")
Y <- Y/rowSums(Y)
row.names(Y) <- sampleIDs
M <- as.matrix(MC[match(valid,MC$SampleID),mineralcols,drop=FALSE])
W <- as.matrix(EV[match(valid,EV$station),watercols,drop=FALSE])
S <- as.matrix(EV[match(valid,EV$station),sedcols,drop=FALSE])
choosePC <- function(A,prefix){
 if (any(!is.finite(A))) stop("Nonfinite predictor")
 fit<-prcomp(A,center=TRUE,scale.=TRUE)
 k<-which(cumsum(fit$sdev^2/sum(fit$sdev^2)) >= 0.80)[1]
 out<-as.data.frame(fit$x[,seq_len(k),drop=FALSE]);names(out)<-paste0(prefix,seq_len(k))
 attr(out,"variance")<-sum(fit$sdev[seq_len(k)]^2)/sum(fit$sdev^2)
 out
}
Xm<-choosePC(M,"M"); Xw<-choosePC(W,"W"); Xs<-choosePC(S,"S")
blocks <- list(M=Xm,W=Xw,S=Xs)
allpred <- data.frame(Xm,Xw,Xs,check.names=FALSE)
# dbRDA uses Bray-Curtis with Lingoes correction to ensure nonnegative axes.
# Partial pure fractions tested conditional on the OTHER TWO blocks.
pure <- list();set.seed(20261013)
for (b in names(blocks)) {
 others <- setdiff(names(blocks),b)
 rhs <- paste(names(blocks[[b]]),collapse=" + ")
 condvars<-unlist(lapply(others,function(t)names(blocks[[t]])))
 form <- as.formula(paste("Y ~",rhs,"+ Condition(",paste(condvars,collapse=" + "),")"))
 model <- vegan::dbrda(form,data=allpred,distance="bray",add="lingoes")
 test <- vegan::anova.cca(model,permutations=9999)
 adj <- vegan::RsquareAdj(model)$adj.r.squared
 pure[[b]] <- data.frame(Block=b,N=nrow(Y),Axes=ncol(blocks[[b]]),
    PCA_variance=attr(blocks[[b]],"variance"),Partial_dbrda_adjusted_R2=adj,
    pseudo_F=unname(test$F[1]),P=unname(test$`Pr(>F)`[1]),Permutations=9999)
}
write.csv(do.call(rbind,pure),file.path(outdir,"pure_fractions_dbrda.csv"),row.names=FALSE)
write.csv(data.frame(Mineral_SampleID=valid,Genus_SampleID=sampleIDs),file.path(outdir,"matched_70.csv"),row.names=FALSE)
cat("dbRDA/CZM run complete. Outputs: ",
    file.path(outdir,"pure_fractions_dbrda.csv"), "\n", sep="")
cat("Compare actual outputs with final manuscript; never substitute Hellinger-RDA estimates.\n")
