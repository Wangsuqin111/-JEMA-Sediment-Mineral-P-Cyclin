# Minimal manuscript/Supplementary replacements grounded in final R output

## Methods 2.5 — replace the *variation partition* portion only

"Variation partitioning was conducted on 70 matched sediment samples to assess the conditional associations of sediment mineral composition, water-column conditions and sediment physicochemical properties with genus-level community composition. The mineral block comprised centred log-ratio (CLR) coordinates from the recovered multiplicative zero-replacement (CZM) analysis of the ten bulk-XRD components; water-column and sediment physicochemical blocks comprised eight and seven variables, respectively. Each environmental block was standardized and reduced by principal component analysis to the minimum number of axes explaining at least 80% of its within-block variance (five mineral, five water and four sediment axes). Partial distance-based redundancy analysis (dbRDA) was conducted on sample-normalized genus profiles using Bray–Curtis dissimilarities with Lingoes correction. Each block was tested conditional on the other two, with 9,999 permutations (random seed 20261013). Adjusted R² quantified the unique explanatory fraction for each block."

## Results — add/replace variation partition statement

"Variation partitioning based on 70 matched samples identified a small but statistically supported conditional mineral fraction (partial dbRDA adjusted R² = 0.0251, P = 0.0193), alongside fractions associated with water-column conditions (adjusted R² = 0.0390, P = 0.0057) and sediment physicochemical properties (adjusted R² = 0.0618, P = 0.0011; 9,999 permutations). These fractions describe multivariate associations and do not imply independent causal effects of minerals."

## Supplementary Table S11 — replace Hellinger-RDA table

| Predictor block | N | PCA axes | PCA variance retained | Pure partial-dbRDA adjusted R² | pseudo-F | Permutation P |
|---|---:|---:|---:|---:|---:|---:|
| Mineral (CZM-CLR) | 70 | 5 | 80.87% | 0.025124 | 1.3745 | 0.0193 |
| Water-column | 70 | 5 | 87.22% | 0.039002 | 1.5813 | 0.0057 |
| Sediment physicochemistry | 70 | 4 | 89.95% | 0.061841 | 2.1330 | 0.0011 |

## Important other reversions

- Prior *October 13 re-analysis* had changed the **ten-component CZM CLR-PC1 45.0%** to 52.8% using a different zero-replacement rule. Restore **45.0%** and the October-7 CZM code and historical scores.
- Restore the source-supported continuous PERMANOVA effect sizes: genus **R² = 0.0339** and P-function **R² = 0.0385**. Under the included seed (9999 permutations), **P = 0.0128** and **P = 0.0195**, respectively. These are statistically supported but small associations (not causal reorganization).
- Original Ward.D2/Aitchison robustness confirmed on researcher's R system: **ARI = 0.570432, 9 of 75 reassigned**, not the alternative method's ARI=.111 and 24 reassigned.
- A full reversion of the October-13 manuscript/figures is needed if that draft is still in use. The archive **does not automatically edit Word files**; it includes the specific replacement text above to avoid suggesting otherwise.
