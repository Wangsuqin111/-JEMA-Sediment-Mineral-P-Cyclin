@echo off
setlocal
cd /d "%~dp0"
where Rscript >nul 2>nul
if errorlevel 1 (echo Rscript not found. Install R and zCompositions/openxlsx packages. & pause & exit /b 1)
Rscript code/01_recovered_CZM_CLR_PCA.R
pause
